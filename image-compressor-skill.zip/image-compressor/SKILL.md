---
name: image-compressor
description: 在本地将 JPG、PNG、WebP 图片或整个文件夹批量压缩到指定文件大小，裁剪为 3:4 或 1:1、统一尺寸、顺序命名并打包 ZIP。用于头像上传、附件大小限制和批量图片瘦身；不用于图像生成或内容修图。
---

# PicBatchKit · 图片压缩与配图整理

使用随附的 `scripts/compress.py` 处理用户指定的图片。保留原文件，在新目录中输出压缩图片和 JSON 报告。所有处理在本地完成。

默认目标严格小于 1,000,000 字节（1 MB），最长边 1600 像素，输出 JPG。尊重用户给出的目标、尺寸和格式。透明图片默认改用 WebP 保留透明度；明确要求 JPG 时告知透明区域会变为白色。动态图只输出第一帧，并在结果中注明。

如果用户请求“小红书配图整理”，默认使用 3:4、最长边 1200、JPG、每张小于 1 MB、顺序命名和 ZIP；这些是工具预设，不是平台上传限制。默认居中裁剪，提醒检查是否切掉文字或主体；要求保留完整画面时使用白色留边。保持用户明确给出的顺序，文件夹按文件名排序。不要制作封面排版或发布笔记。

## 运行

需要 Python 3 和 Pillow。先使用当前可用且带 Pillow 的 Python；Codex 桌面端可以通过 workspace dependencies 工具发现运行时。没有 Pillow 时在任务目录建立虚拟环境并安装 `requirements.txt`，不要修改系统 Python。

```sh
python <skill目录>/scripts/compress.py <图片或文件夹> [更多路径] --output <新输出目录> --target-kb 1000 --max-edge 1600 --format jpg
```

配图示例：

```sh
python <skill目录>/scripts/compress.py <图片或文件夹> --output <新输出目录> --ratio 3:4 --fit crop --max-edge 1200 --target-kb 1000 --numbered --zip
```

- `--ratio original|3:4|1:1`：普通压缩默认保留原比例。
- `--fit crop|pad`：居中裁剪或白色留边。
- `--numbered`：按处理顺序命名为 01、02、03。
- `--zip`：生成包含成功图片和报告的 ZIP。
- 按预设统一起始尺寸；压缩达到大小限制时可能缩小，最终尺寸以报告为准。小图可能放大，无法增加细节。
- `--format jpg|webp|png`：PNG 使用缩小尺寸达到目标；JPG/WebP 先调整质量再缩小。
- `--recursive`：只有用户要求处理子文件夹时启用。
- `--max-edge 0`：保持原尺寸开始，超出目标时仍会缩小。
- `--target-kb` 采用十进制 KB；脚本验证最终文件严格小于目标。

脚本自动处理 EXIF 旋转，移除 EXIF 等元数据，拒绝覆盖已有文件，输出名冲突时添加序号。压缩结果保存到指定目录；不要把输出目录设为待递归扫描的输入目录。

## 交付

读取 `compression-report.json`，报告成功和失败数量、大小变化及输出目录。某张图片失败时继续处理其他图片，但不要称全部成功。用户需要分享或下载时可将结果打包为 ZIP。若有尺寸缩小、透明背景转换或动态图静态化，简要指出。不要上传图片到外部服务。
